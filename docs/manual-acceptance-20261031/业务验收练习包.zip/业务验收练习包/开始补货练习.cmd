@echo off
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0launch-practice.ps1" -Mode replenish
if errorlevel 1 pause
